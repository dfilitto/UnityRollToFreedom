using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class MainMenu : MonoBehaviour
{
    [SerializeField]
    private string gameName = "Nome do jogo";
    [SerializeField]
    private string firstLevelSceneName = "fase_01";
    [SerializeField]
    private Texture2D gameImageTexture;

    private PanelRenderer panelRenderer;
    private Button btnPlay;
    private Button btnExit;

    private void Awake()
    {
        panelRenderer = GetComponent<PanelRenderer>();
    }

    private void OnEnable()
    {
        panelRenderer.RegisterUIReloadCallback(ConfigureUI);
    }

    private void OnDisable()
    {
        panelRenderer.UnregisterUIReloadCallback(ConfigureUI);
        btnPlay.clicked -= StartGame;
        btnExit.clicked -= StartGame;
    }

    private void ConfigureUI(PanelRenderer renderer, VisualElement root, int version)
    {
        root.Q<Label>("LblTitle").text = gameName;
        root.Q<VisualElement>("GameArt").style.backgroundImage = gameImageTexture;
        btnPlay = root.Q<Button>("BtnPlay");
        btnExit = root.Q<Button>("BtnQuit");

        btnPlay.clicked += StartGame;
        btnExit.clicked += ExitGame;

    }

    private void StartGame()
    {
        SceneManager.LoadScene(firstLevelSceneName);
    }

    private void ExitGame()
    {
        Application.Quit();
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #endif
    }

}
